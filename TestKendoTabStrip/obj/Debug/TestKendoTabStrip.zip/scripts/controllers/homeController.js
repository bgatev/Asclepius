var app = app || {};

(function (scope) {
    scope.map = function () {
        //navigator.geolocation.getCurrentPosition()
    }
})

